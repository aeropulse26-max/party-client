package com.partyclient.ui;

import com.partyclient.PartyClient;
import com.partyclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

/**
 * Tung Tung Sahur walks in and hits you with the bat three times when you die.
 * Sprites live in assets/partyclient/textures/gui/tts_{0,1,2}.png - swap them for your own art.
 */
public final class DeathAnimation {
    private static final Identifier[] FRAMES = {
            new Identifier("partyclient", "textures/gui/tts_0.png"),
            new Identifier("partyclient", "textures/gui/tts_1.png"),
            new Identifier("partyclient", "textures/gui/tts_2.png")};
    private static final int HITS = 3, CYCLE = 800, INTRO = 700, OUTRO = 600;
    private static long start = -1;
    private static int hitsPlayed;
    private DeathAnimation() {}

    public static void start() { start = Util.getMeasuringTimeMs(); hitsPlayed = 0; }

    public static void render(DrawContext ctx, int w, int h) {
        if (!ModuleManager.DEATH.enabled || start < 0) return;
        long t = Util.getMeasuringTimeMs() - start;
        long total = INTRO + HITS * CYCLE + OUTRO;
        if (t > total) return;

        float fadeOut = t > total - OUTRO ? 1f - (t - (total - OUTRO)) / (float) OUTRO : 1f;
        int size = Math.min(h * 55 / 100, 256);
        float slide = Ui.ease(t / (float) INTRO);
        int x = (int) (-size + slide * (w * 0.30f + size * 0.2f));
        int y = h - size - h / 12;

        int frame = 0; boolean hitNow = false; long sinceHit = Long.MAX_VALUE;
        long a = t - INTRO;
        if (a >= 0) {
            int cycle = (int) Math.min(HITS - 1, a / CYCLE);
            float p = (a - cycle * (long) CYCLE) / (float) CYCLE;
            frame = p < 0.45f ? 1 : (p < 0.62f ? 2 : 0);
            if (p >= 0.5f && hitsPlayed <= cycle) { hitsPlayed = cycle + 1; hitNow = true; }
            if (a >= HITS * CYCLE) frame = 0;
            for (int c = 0; c < hitsPlayed; c++) sinceHit = Math.min(sinceHit, a - (c * (long) CYCLE + CYCLE / 2));
        }
        if (hitNow) MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(PartyClient.TUNG, 1.0f));

        // impact flash + shake
        float flash = sinceHit < 280 ? 1f - sinceHit / 280f : 0f;
        if (flash > 0) ctx.fill(0, 0, w, h, Ui.argb(0.35f * flash * fadeOut, 0xFF0000));
        int sx = flash > 0 ? (int) ((Math.random() - 0.5) * 10 * flash) : 0, sy = flash > 0 ? (int) ((Math.random() - 0.5) * 10 * flash) : 0;

        ctx.setShaderColor(1, 1, 1, fadeOut);
        ctx.drawTexture(FRAMES[frame], x + sx, y + sy, size, size, 0, 0, 64, 64, 64, 64);
        ctx.setShaderColor(1, 1, 1, 1);

        if (sinceHit < 450) {
            Text label = Text.literal("TUNG TUNG TUNG SAHUR!");
            ctx.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, label, w / 2 + sx, h / 4 + sy, Ui.argb(fadeOut * (1 - sinceHit / 450f), 0xFFE08A));
        }
    }
}
