package com.partyclient.ui;

import com.partyclient.module.Module;
import com.partyclient.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** The "Mods" menu: toggle client mods and tweak their settings. */
public class ModsScreen extends Screen {
    private static final int ROW_H = 38, W = 330;
    private final Screen parent;
    private double scroll;

    public ModsScreen(Screen parent) { super(Text.literal("Mods")); this.parent = parent; }

    private int left() { return width / 2 - W / 2; }
    private int top() { return 62; }
    private int rowY(int i) { return top() + i * (ROW_H + 4) - (int) scroll; }
    private int viewBottom() { return height - 34; }
    private double maxScroll() { return Math.max(0, ModuleManager.ALL.size() * (ROW_H + 4) - (viewBottom() - top())); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.currentTimeMillis();
        ctx.fillGradient(0, 0, width, height, 0xFF050508, 0xFF0B0B14);
        Ui.stars(ctx, width, height, now);
        Ui.ribbons(ctx, width, height, now);
        Ui.logo(ctx, width / 2, 8, 28, 1f);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Party Client  -  Mods"), width / 2, 40, 0xFFFFFFFF);

        ctx.enableScissor(0, top() - 2, width, viewBottom());
        for (int i = 0; i < ModuleManager.ALL.size(); i++) {
            Module m = ModuleManager.ALL.get(i);
            int x = left(), y = rowY(i);
            boolean hover = Ui.inside(mx, my, x, y, W, ROW_H) && my < viewBottom();
            ctx.fill(x, y, x + W, y + ROW_H, Ui.argb(hover ? 0.12f : 0.07f, 0xFFFFFF));
            ctx.fill(x, y, x + 2, y + ROW_H, m.enabled ? 0xFFFFFFFF : 0x33FFFFFF);
            ctx.drawTextWithShadow(textRenderer, m.name, x + 10, y + 7, 0xFFFFFFFF);
            ctx.drawTextWithShadow(textRenderer, trim(m.desc, W - 120), x + 10, y + 21, 0xFF8B8B9C);
            // toggle pill
            int px = x + W - 38, py = y + 6;
            ctx.fill(px, py, px + 28, py + 12, m.enabled ? 0xFFFFFFFF : 0xFF2A2A36);
            int knob = m.enabled ? px + 16 : px + 2;
            ctx.fill(knob, py + 2, knob + 10, py + 10, m.enabled ? 0xFF000000 : 0xFF777788);
            // slider / choice controls
            if (m.hasValue) {
                int vx = x + W - 96;
                ctx.drawTextWithShadow(textRenderer, "<", vx, y + 24, 0xFFFFFFFF);
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(String.format("%.2f", m.value)), vx + 30, y + 24, 0xFFFFFFFF);
                ctx.drawTextWithShadow(textRenderer, ">", vx + 56, y + 24, 0xFFFFFFFF);
            } else if (m.options != null) {
                ctx.drawTextWithShadow(textRenderer, m.options[m.option] + " >", x + W - 96, y + 24, 0xFFFFFFFF);
            }
        }
        ctx.disableScissor();

        boolean over = Ui.inside(mx, my, width / 2 - 50, height - 28, 100, 20);
        ctx.fill(width / 2 - 50, height - 28, width / 2 + 50, height - 8, over ? 0xFFFFFFFF : 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Done"), width / 2, height - 22, over ? 0xFF000000 : 0xFFFFFFFF);
    }

    private String trim(String s, int px) {
        while (textRenderer.getWidth(s) > px && s.length() > 4) s = s.substring(0, s.length() - 4) + "...";
        return s;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (Ui.inside(mx, my, width / 2 - 50, height - 28, 100, 20)) { close(); return true; }
        if (my >= viewBottom() || my < top() - 2) return super.mouseClicked(mx, my, button);
        for (int i = 0; i < ModuleManager.ALL.size(); i++) {
            Module m = ModuleManager.ALL.get(i);
            int x = left(), y = rowY(i);
            if (!Ui.inside(mx, my, x, y, W, ROW_H)) continue;
            if (m.hasValue && Ui.inside(mx, my, x + W - 100, y + 20, 18, 14)) m.nudge(-1);
            else if (m.hasValue && Ui.inside(mx, my, x + W - 44, y + 20, 18, 14)) m.nudge(1);
            else if (m.options != null && Ui.inside(mx, my, x + W - 100, y + 20, 96, 14)) m.cycle();
            else m.enabled = !m.enabled;
            ModuleManager.save();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll - amount * 18));
        return true;
    }

    @Override public void close() { ModuleManager.save(); client.setScreen(parent); }
}
