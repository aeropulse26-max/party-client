package com.partyclient.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Shared drawing helpers for Party Client screens. */
public final class Ui {
    public static final Identifier LOGO = new Identifier("partyclient", "textures/gui/logo_white.png");
    private Ui() {}

    public static int argb(float a, int rgb) { return ((int) (Math.max(0, Math.min(1, a)) * 255) << 24) | (rgb & 0xFFFFFF); }
    public static float ease(float t) { t = Math.max(0, Math.min(1, t)); return 1 - (1 - t) * (1 - t) * (1 - t); }

    public static void logo(DrawContext ctx, int cx, int y, int size, float alpha) {
        ctx.setShaderColor(1, 1, 1, alpha);
        ctx.drawTexture(LOGO, cx - size / 2, y, size, size, 0, 0, 256, 256, 256, 256);
        ctx.setShaderColor(1, 1, 1, 1);
    }

    /** Animated vertical wave ribbons on the right edge, like the reference client. */
    public static void ribbons(DrawContext ctx, int w, int h, long ms) {
        double t = ms / 1000.0;
        for (int r = 0; r < 3; r++) {
            double base = w - 60 + r * 26, amp = 22 + r * 8, freq = 0.018 + r * 0.004;
            int color = argb(0.22f - r * 0.05f, 0xFFFFFF);
            for (int y = 0; y < h; y += 2) {
                int x = (int) (base + Math.sin(y * freq + t * (0.8 + r * 0.25) + r) * amp);
                ctx.fill(x, y, x + 1, y + 2, color);
                ctx.fill(x + 3, y, x + 4, y + 2, argb(0.06f, 0xFFFFFF));
            }
        }
    }

    /** Slowly rising star particles. */
    public static void stars(DrawContext ctx, int w, int h, long ms) {
        for (int i = 0; i < 40; i++) {
            long seed = i * 7919L;
            float x = (seed * 31 % 1000) / 1000f * w;
            float speed = 6 + (seed % 7) * 2;
            float y = h - ((ms / 1000f * speed + (seed % 500)) % (h + 20));
            float tw = (float) (0.3 + 0.3 * Math.sin(ms / 600.0 + i));
            ctx.fill((int) x, (int) y, (int) x + 1, (int) y + 1, argb(tw, 0xFFFFFF));
        }
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    public static MinecraftClient mc() { return MinecraftClient.getInstance(); }
}
