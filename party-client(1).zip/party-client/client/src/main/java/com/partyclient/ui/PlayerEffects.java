package com.partyclient.ui;

import com.partyclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.ArrayList;
import java.util.List;

/** Swirling rings around whatever you hit (like the orange rings in the reference video). */
public final class PlayerEffects {
    private static final int DURATION = 24;
    private record Ring(int entityId, int[] age) {}
    private static final List<Ring> RINGS = new ArrayList<>();
    private PlayerEffects() {}

    public static void add(int entityId) { RINGS.removeIf(r -> r.entityId == entityId); RINGS.add(new Ring(entityId, new int[]{0})); }

    private static ParticleEffect particle() {
        return switch (ModuleManager.EFFECTS.option) {
            case 1 -> ParticleTypes.SOUL_FIRE_FLAME;
            case 2 -> ParticleTypes.END_ROD;
            case 3 -> ParticleTypes.ELECTRIC_SPARK;
            case 4 -> ParticleTypes.HEART;
            default -> ParticleTypes.FLAME;
        };
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null) { RINGS.clear(); return; }
        RINGS.removeIf(r -> {
            Entity e = mc.world.getEntityById(r.entityId);
            if (e == null || ++r.age[0] > DURATION) return true;
            double a = r.age[0];
            for (int ring = 0; ring < 2; ring++) {
                double radius = (ring == 0 ? 0.55 : 0.95) + a * 0.012;
                double y = e.getY() + 0.05 + a * (ring == 0 ? 0.075 : 0.045);
                for (int p = 0; p < 6; p++) {
                    double ang = a * (ring == 0 ? 0.55 : -0.4) + p * Math.PI / 3.0;
                    mc.world.addParticle(particle(), e.getX() + Math.cos(ang) * radius, y, e.getZ() + Math.sin(ang) * radius, 0, 0.004, 0);
                }
            }
            return false;
        });
    }
}
