package com.partyclient.ui;

import com.partyclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public final class Hud {
    private Hud() {}

    public static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ModuleManager.HUD.enabled || mc.player == null || mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        String text = mc.getCurrentFps() + " fps  |  " + ping + " ms";
        int w = mc.textRenderer.getWidth(text) + 22;
        ctx.fill(4, 4, 4 + w, 20, Ui.argb(0.55f, 0x08080C));
        ctx.fill(4, 4, 6, 20, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer, text, 12, 8, 0xFFFFFFFF);
    }
}
