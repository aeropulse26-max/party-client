package com.partyclient.module;

/** A toggleable client feature, optionally with a numeric slider or a list of choices. */
public class Module {
    public final String id, name, desc;
    public boolean enabled;
    public final boolean hasValue;
    public float value, min, max, step;
    public final String[] options;
    public int option;

    public Module(String id, String name, String desc, boolean enabled) {
        this(id, name, desc, enabled, false, 0, 0, 0, 0, null);
    }
    public Module slider(float value, float min, float max, float step) {
        return new Module(id, name, desc, enabled, true, value, min, max, step, null);
    }
    public Module choices(String... opts) {
        return new Module(id, name, desc, enabled, false, 0, 0, 0, 0, opts);
    }
    private Module(String id, String name, String desc, boolean enabled, boolean hasValue, float value, float min, float max, float step, String[] options) {
        this.id = id; this.name = name; this.desc = desc; this.enabled = enabled;
        this.hasValue = hasValue; this.value = value; this.min = min; this.max = max; this.step = step; this.options = options;
    }

    public void nudge(int dir) {
        value = Math.round(Math.max(min, Math.min(max, value + dir * step)) * 100f) / 100f;
    }
    public void cycle() { if (options != null) option = (option + 1) % options.length; }
}
