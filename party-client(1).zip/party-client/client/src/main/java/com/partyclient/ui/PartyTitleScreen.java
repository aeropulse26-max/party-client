package com.partyclient.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

public class PartyTitleScreen extends Screen {
    private static boolean entered; // stays true after the first "press to enter"
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Minecraft Settings", "Client", "Quit Game"};
    private final float[] hover = new float[LABELS.length];
    private long openedAt = Util.getMeasuringTimeMs(), enteredAt = entered ? 0 : -1;

    public PartyTitleScreen() { super(Text.literal("Party Client")); if (entered) enteredAt = openedAt - 2000; }

    @Override public boolean shouldCloseOnEsc() { return false; }

    private void enter() { if (!entered) { entered = true; enteredAt = Util.getMeasuringTimeMs(); } }

    private int btnX() { return width / 2 - 60; }
    private int btnY(int i) { return height / 2 - 6 + i * 22; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = Util.getMeasuringTimeMs();
        ctx.fillGradient(0, 0, width, height, 0xFF050508, 0xFF0B0B14);
        Ui.stars(ctx, width, height, now);
        Ui.ribbons(ctx, width, height, now);

        float fadeIn = Ui.ease((now - openedAt) / 700f);
        float t = entered ? Ui.ease((now - enteredAt) / 650f) : 0f;       // 0 = splash, 1 = menu
        int size = (int) (72 - 28 * t);
        int logoY = (int) ((height / 2 - 44) - (t * 52));
        float bob = (float) Math.sin(now / 700.0) * 2f * (1 - t);
        Ui.logo(ctx, width / 2, logoY + (int) bob, size, fadeIn);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Party Client"), width / 2, logoY + size + 4, Ui.argb(fadeIn, 0xFFFFFF));

        if (t < 1f) { // "Press to enter" pulses, fades out on entering
            float pulse = 0.55f + 0.45f * (float) Math.sin(now / 450.0);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Press to enter"), width / 2, logoY + size + 22, Ui.argb(pulse * (1 - t) * fadeIn, 0xB8B8C8));
        }
        if (t > 0f) {
            for (int i = 0; i < LABELS.length; i++) {
                float local = Ui.ease(t * 1.6f - i * 0.12f);          // staggered slide-in
                boolean over = local > 0.95f && Ui.inside(mx, my, btnX(), btnY(i), 120, 18);
                hover[i] += ((over ? 1f : 0f) - hover[i]) * Math.min(1f, delta * 0.45f);
                int x = btnX() + (int) ((1 - local) * 14);
                if (hover[i] > 0.01f) ctx.fill(x, btnY(i), x + (int) (120 * hover[i]), btnY(i) + 18, Ui.argb(0.18f * local, 0xFFFFFF));
                int col = over ? 0xFFFFFF : 0xB4B4C2;
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(LABELS[i]), x + 60, btnY(i) + 5, Ui.argb(local, col));
            }
        }
        String user = client != null ? client.getSession().getUsername() : "";
        ctx.drawTextWithShadow(textRenderer, user, 6, height - 12, Ui.argb(0.5f, 0xFFFFFF));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (!entered) { enter(); return true; }
        for (int i = 0; i < LABELS.length; i++) {
            if (Ui.inside(mx, my, btnX(), btnY(i), 120, 18)) {
                switch (i) {
                    case 0 -> client.setScreen(new SelectWorldScreen(this));
                    case 1 -> client.setScreen(new MultiplayerScreen(this));
                    case 2 -> client.setScreen(new OptionsScreen(this, client.options));
                    case 3 -> client.setScreen(new ModsScreen(this));
                    default -> client.scheduleStop();
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (!entered) { enter(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
