package com.partyclient.module;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;

public class ModuleManager {
    public static final Module TITLE      = new Module("title", "Party Title Screen", "Replace the main menu with the Party Client menu.", true);
    public static final Module HUD        = new Module("hud", "Info HUD", "Show FPS and ping in the top-left corner.", true);
    public static final Module STRETCH    = new Module("stretch", "Stretch Screen", "Stretch the game horizontally (stretched-res look).", false).slider(1.25f, 0.5f, 2.0f, 0.05f);
    public static final Module EFFECTS    = new Module("effects", "Player Effects", "Swirling ring effects when you hit a player or mob.", true)
            .choices("Flame", "Soul Fire", "End Rod", "Electric Spark", "Hearts");
    public static final Module DEATH      = new Module("death", "Death Animation", "Tung Tung Sahur hits you with the bat when you die.", true);
    public static final Module ZOOM       = new Module("zoom", "Zoom", "Hold the Zoom key (default C) to zoom in.", true).slider(4f, 1.5f, 10f, 0.5f);
    public static final Module FULLBRIGHT = new Module("fullbright", "Fullbright", "See clearly in the dark (client-side night vision).", false);

    public static final List<Module> ALL = List.of(TITLE, HUD, EFFECTS, DEATH, STRETCH, ZOOM, FULLBRIGHT);
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("partyclient.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m : ALL) {
                if (!root.has(m.id)) continue;
                JsonObject o = root.getAsJsonObject(m.id);
                if (o.has("enabled")) m.enabled = o.get("enabled").getAsBoolean();
                if (o.has("value")) m.value = o.get("value").getAsFloat();
                if (o.has("option") && m.options != null) m.option = Math.floorMod(o.get("option").getAsInt(), m.options.length);
            }
        } catch (Exception ignored) { /* keep defaults on a corrupt config */ }
    }

    public static void save() {
        JsonObject root = new JsonObject();
        for (Module m : ALL) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.enabled);
            if (m.hasValue) o.addProperty("value", m.value);
            if (m.options != null) o.addProperty("option", m.option);
            root.add(m.id, o);
        }
        try { Files.writeString(FILE, GSON.toJson(root)); } catch (IOException ignored) { }
    }
}
