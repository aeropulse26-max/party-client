package com.partyclient.mixin;

import com.partyclient.PartyClient;
import com.partyclient.module.ModuleManager;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    /** Stretch screen: scales the projection horizontally (like a stretched resolution). */
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"))
    private void party$stretch(double fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (ModuleManager.STRETCH.enabled) cir.getReturnValue().scaleLocal(ModuleManager.STRETCH.value, 1f, 1f);
    }

    /** Zoom: hold the zoom key to narrow the FOV. */
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void party$zoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        if (ModuleManager.ZOOM.enabled && PartyClient.zoomKey != null && PartyClient.zoomKey.isPressed())
            cir.setReturnValue(cir.getReturnValue() / ModuleManager.ZOOM.value);
    }
}
