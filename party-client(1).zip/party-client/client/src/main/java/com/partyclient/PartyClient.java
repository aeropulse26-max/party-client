package com.partyclient;

import com.partyclient.module.ModuleManager;
import com.partyclient.ui.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class PartyClient implements ClientModInitializer {
    public static final String ID = "partyclient";
    public static final Identifier TUNG_ID = new Identifier(ID, "tung");
    public static final SoundEvent TUNG = SoundEvent.of(TUNG_ID);
    public static KeyBinding modsKey, zoomKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.load();
        Registry.register(Registries.SOUND_EVENT, TUNG_ID, TUNG);

        modsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.partyclient.mods", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.partyclient"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.partyclient.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.partyclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Swap the vanilla title screen for ours
            if (ModuleManager.TITLE.enabled && client.currentScreen != null && client.currentScreen.getClass() == TitleScreen.class)
                client.setScreen(new PartyTitleScreen());
            while (modsKey.wasPressed()) if (client.currentScreen == null) client.setScreen(new ModsScreen(null));
            fullbright(client);
            PlayerEffects.tick(client);
        });

        HudRenderCallback.EVENT.register(Hud::render);

        // "Party Mods" button in the pause menu + death animation overlay
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen)
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Party Mods"), b -> client.setScreen(new ModsScreen(screen)))
                        .dimensions(6, 6, 90, 20).build());
            if (screen instanceof DeathScreen) {
                DeathAnimation.start();
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> DeathAnimation.render(ctx, s.width, s.height));
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && ModuleManager.EFFECTS.enabled) PlayerEffects.add(entity.getId());
            return ActionResult.PASS;
        });
    }

    private static boolean fbApplied;
    private static void fullbright(MinecraftClient c) {
        if (c.player == null) return;
        if (ModuleManager.FULLBRIGHT.enabled) {
            if (c.player.age % 100 == 0 || !fbApplied)
                c.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
            fbApplied = true;
        } else if (fbApplied) { c.player.removeStatusEffect(StatusEffects.NIGHT_VISION); fbApplied = false; }
    }
}
