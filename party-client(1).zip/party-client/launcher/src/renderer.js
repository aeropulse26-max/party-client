const $ = s => document.querySelector(s);
const el = (t, props = {}, ...kids) => { const e = Object.assign(document.createElement(t), props); kids.forEach(k => e.append(k)); return e; };
let toastT;
const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.remove('hidden'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.add('hidden'), 5000); };
const err = e => toast(String(e.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''));

document.querySelectorAll('[data-w]').forEach(b => b.onclick = () => party.win(b.dataset.w));
document.querySelectorAll('.nav').forEach(b => b.onclick = () => {
  document.querySelectorAll('.nav,.page').forEach(x => x.classList.remove('on'));
  b.classList.add('on'); $('#page-' + b.dataset.page).classList.add('on');
  if (b.dataset.page === 'packs') { loadInstalled(); search(''); }
});

// ----- account -----
function showUser(u) {
  $('#login').classList.toggle('hidden', !!u); $('#who').classList.toggle('hidden', !u);
  if (u) { $('#uname').textContent = u.name; $('#head').src = `https://mc-heads.net/avatar/${u.uuid}/34`; }
}
$('#login').onclick = async () => { try { showUser(await party.login()); } catch (e) { err(e); } };
$('#logout').onclick = async () => { await party.logout(); showUser(null); };
party.on('auth:changed', showUser); party.me().then(showUser);

// ----- versions / play -----
(async () => {
  const cfg = await party.getCfg(), vs = await party.versions().catch(() => [cfg.selected]);
  vs.forEach((v, i) => $('#ver').append(el('option', { value: v, textContent: `${v}${i === 0 ? ' (latest)' : ''} - Fabric` })));
  $('#ver').value = vs.includes(cfg.selected) ? cfg.selected : vs[0];
  $('#ram').value = cfg.ram; $('#java').value = cfg.javaPath; $('#close').checked = cfg.closeOnLaunch;
})();
const busy = on => { $('#play').disabled = on; if (!on) $('#bar').classList.add('hidden'); };
$('#play').onclick = async () => { busy(true); try { await party.launch({ mc: $('#ver').value }); } catch (e) { err(e); busy(false); } };
party.on('progress', p => { $('#bar').classList.remove('hidden'); $('#barlabel').textContent = p.label; $('#barfill').style.width = p.pct + '%'; });
party.on('launched', () => { $('#bar').classList.add('hidden'); toast('Game started'); });
party.on('closed', () => busy(false)); party.on('toast', toast);

// ----- modpacks -----
let st; $('#q').oninput = e => { clearTimeout(st); st = setTimeout(() => search(e.target.value), 350); };
async function search(q) {
  const box = $('#results'); box.replaceChildren(el('p', { textContent: 'Loading...' }));
  try {
    const hits = await party.searchPacks({ q });
    box.replaceChildren(...hits.map(h => el('div', { className: 'card' },
      h.icon ? el('img', { src: h.icon }) : el('div', { className: 'ph' }),
      el('div', {}, el('h3', { textContent: h.title }), el('p', { textContent: h.desc }),
        el('button', { textContent: 'Install', onclick: async ev => {
          ev.target.disabled = true; try { await party.installPack({ slug: h.slug, title: h.title }); toast(h.title + ' installed'); loadInstalled(); } catch (e) { err(e); } ev.target.disabled = false; } })))));
  } catch (e) { box.replaceChildren(el('p', { textContent: 'Could not load modpacks.' })); }
}
async function loadInstalled() {
  const list = await party.installedPacks();
  $('#mine').replaceChildren(...(list.length ? list.map(p => el('div', { className: 'card' }, el('div', { className: 'ph' }),
    el('div', {}, el('h3', { textContent: p.title }), el('p', { textContent: `Minecraft ${p.mc} - Fabric` }),
      el('button', { textContent: 'Play', onclick: async () => { busy(true); try { await party.playPack({ dir: p.dir }); } catch (e) { err(e); busy(false); } } }),
      el('button', { className: 'd', textContent: 'Remove', onclick: async () => { await party.removePack({ dir: p.dir }); loadInstalled(); } }))))
    : [el('p', { textContent: 'No modpacks installed yet.' })]));
}
document.querySelectorAll('.tab').forEach(t => t.onclick = () => {
  document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === t));
  $('#tab-browse').classList.toggle('hidden', t.dataset.tab !== 'browse'); $('#tab-installed').classList.toggle('hidden', t.dataset.tab !== 'installed');
});

// ----- settings -----
$('#save').onclick = async () => { await party.setCfg({ ram: Math.max(1, +$('#ram').value || 4), javaPath: $('#java').value.trim(), closeOnLaunch: $('#close').checked }); toast('Saved'); };
$('#folder').onclick = () => party.openFolder();
