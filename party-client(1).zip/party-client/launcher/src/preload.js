const { contextBridge, ipcRenderer: ipc } = require('electron');
const inv = ch => a => ipc.invoke(ch, a);
contextBridge.exposeInMainWorld('party', {
  win: a => ipc.send('win', a),
  login: inv('auth:login'), logout: inv('auth:logout'), me: inv('auth:me'),
  versions: inv('versions:list'), launch: inv('game:launch'),
  searchPacks: inv('packs:search'), installedPacks: inv('packs:installed'),
  installPack: inv('packs:install'), playPack: inv('packs:play'), removePack: inv('packs:remove'),
  getCfg: inv('cfg:get'), setCfg: inv('cfg:set'), openFolder: inv('open:folder'),
  on: (ch, fn) => ipc.on(ch, (_, d) => fn(d))
});
