// Party Client Launcher - main process
const { app, BrowserWindow, ipcMain, shell, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const AdmZip = require('adm-zip');
const { Client } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const DATA = app.getPath('userData');
const GAME_DIR = path.join(DATA, 'minecraft');
const INSTANCES = path.join(DATA, 'instances');
const CFG_FILE = path.join(DATA, 'config.json');
const SESSION_FILE = path.join(DATA, 'session.bin');
const UA = 'PartyClient/1.0 (launcher)';
[GAME_DIR, INSTANCES].forEach(d => fs.mkdirSync(d, { recursive: true }));

let win, session = null; // session = { mclc, name, uuid, refresh }
const cfg = { ram: 4, javaPath: '', closeOnLaunch: false, selected: '1.20.1', ...readJson(CFG_FILE, {}) };
const saveCfg = () => fs.writeFileSync(CFG_FILE, JSON.stringify(cfg, null, 2));
function readJson(f, d) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } }

// ---------- helpers ----------
function getJson(url) {
  return new Promise((res, rej) => {
    https.get(url, { headers: { 'User-Agent': UA } }, r => {
      if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location) return res(getJson(r.headers.location));
      let b = ''; r.on('data', c => b += c);
      r.on('end', () => { try { res(JSON.parse(b)); } catch (e) { rej(e); } });
    }).on('error', rej);
  });
}
function download(url, dest, onPct) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  return new Promise((res, rej) => {
    https.get(url, { headers: { 'User-Agent': UA } }, r => {
      if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location) { r.resume(); return res(download(new URL(r.headers.location, url).href, dest, onPct)); }
      if (r.statusCode !== 200) { r.resume(); return rej(new Error('Download failed (' + r.statusCode + ')')); }
      const total = +r.headers['content-length'] || 0; let got = 0;
      if (onPct && total) r.on('data', c => { got += c.length; onPct(Math.round(got / total * 100)); });
      const f = fs.createWriteStream(dest);
      r.pipe(f); f.on('finish', () => f.close(res)); f.on('error', rej);
    }).on('error', rej);
  });
}
const send = (ch, data) => win && !win.isDestroyed() && win.webContents.send(ch, data);
const cmp = (a, b) => { const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };

// ---------- window ----------
function createWindow() {
  win = new BrowserWindow({
    width: 1100, height: 700, minWidth: 960, minHeight: 600, frame: false,
    backgroundColor: '#07070c', icon: path.join(__dirname, '../assets/logo.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(async () => { createWindow(); await restoreSession(); });
app.on('window-all-closed', () => app.quit());
ipcMain.on('win', (_, a) => { if (a === 'min') win.minimize(); if (a === 'max') win.isMaximized() ? win.unmaximize() : win.maximize(); if (a === 'close') win.close(); });

// ---------- auth (Microsoft -> Xbox -> Minecraft) ----------
async function applyToken(xbox) {
  const mc = await xbox.getMinecraft();
  session = { mclc: mc.mclc(), name: mc.profile.name, uuid: mc.profile.id, refresh: xbox.save() };
  if (safeStorage.isEncryptionAvailable()) fs.writeFileSync(SESSION_FILE, safeStorage.encryptString(session.refresh));
  return { name: session.name, uuid: session.uuid };
}
async function restoreSession() {
  try {
    if (!fs.existsSync(SESSION_FILE) || !safeStorage.isEncryptionAvailable()) return;
    const refresh = safeStorage.decryptString(fs.readFileSync(SESSION_FILE));
    const xbox = await new Auth('select_account').refresh(refresh);
    send('auth:changed', await applyToken(xbox));
  } catch { /* user will sign in manually */ }
}
ipcMain.handle('auth:login', async () => {
  const xbox = await new Auth('select_account').launch('electron');
  const user = await applyToken(xbox); return user;
});
ipcMain.handle('auth:logout', () => { session = null; fs.rmSync(SESSION_FILE, { force: true }); return true; });
ipcMain.handle('auth:me', () => session && { name: session.name, uuid: session.uuid });

// ---------- versions (Fabric only, 1.20.1 -> latest) ----------
ipcMain.handle('versions:list', async () => {
  const [mojang, fabric] = await Promise.all([
    getJson('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json'),
    getJson('https://meta.fabricmc.net/v2/versions/game')
  ]);
  const fabricOk = new Set(fabric.map(v => v.version));
  return mojang.versions
    .filter(v => v.type === 'release' && /^\d+\.\d+(\.\d+)?$/.test(v.id) && cmp(v.id, '1.20.1') >= 0 && fabricOk.has(v.id))
    .sort((a, b) => cmp(b.id, a.id)).map(v => v.id);
});

async function ensureFabric(mc, loaderPref) {
  const loaders = await getJson('https://meta.fabricmc.net/v2/versions/loader/' + mc);
  const loader = (loaderPref && loaders.find(l => l.loader.version === loaderPref)) || loaders.find(l => l.loader.stable) || loaders[0];
  const id = `fabric-loader-${loader.loader.version}-${mc}`;
  const jf = path.join(GAME_DIR, 'versions', id, id + '.json');
  if (!fs.existsSync(jf)) {
    const prof = await getJson(`https://meta.fabricmc.net/v2/versions/loader/${mc}/${loader.loader.version}/profile/json`);
    fs.mkdirSync(path.dirname(jf), { recursive: true });
    fs.writeFileSync(jf, JSON.stringify(prof));
  }
  return id;
}
async function modrinthFile(slug, mc) {
  const url = `https://api.modrinth.com/v2/project/${slug}/version?game_versions=${encodeURIComponent(JSON.stringify([mc]))}&loaders=${encodeURIComponent('["fabric"]')}`;
  const v = (await getJson(url))[0]; if (!v) return null;
  const f = v.files.find(x => x.primary) || v.files[0]; return f;
}
async function ensureClientMods(mc, modsDir, withClient) {
  fs.mkdirSync(modsDir, { recursive: true });
  const api = await modrinthFile('fabric-api', mc);
  if (api && !fs.existsSync(path.join(modsDir, api.filename))) {
    fs.readdirSync(modsDir).filter(f => f.startsWith('fabric-api-')).forEach(f => fs.rmSync(path.join(modsDir, f)));
    send('progress', { label: 'Downloading Fabric API', pct: 0 });
    await download(api.url, path.join(modsDir, api.filename));
  }
  if (withClient) { // Party Client mod jars are built per MC version and bundled in /bundled
    const dir = path.join(__dirname, '..', 'bundled');
    const jar = fs.existsSync(dir) && fs.readdirSync(dir).find(f => f.startsWith('partyclient-') && f.includes('+mc' + mc + '.jar'));
    fs.readdirSync(modsDir).filter(f => f.startsWith('partyclient-')).forEach(f => fs.rmSync(path.join(modsDir, f)));
    if (jar) fs.copyFileSync(path.join(dir, jar), path.join(modsDir, jar));
    else return { warn: `No Party Client jar bundled for ${mc}. Build it from /client (see README).` };
  }
  return {};
}

// ---------- Java 21 (auto-downloaded, no install needed) ----------
const JAVA_DIR = path.join(DATA, 'runtime', 'java21');
function findJava(dir = JAVA_DIR, depth = 0) {
  if (depth > 5 || !fs.existsSync(dir)) return null;
  const exe = path.join(dir, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');
  if (fs.existsSync(exe)) return exe;
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
    if (d.isDirectory()) { const r = findJava(path.join(dir, d.name), depth + 1); if (r) return r; }
  }
  return null;
}
async function ensureJava() {
  if (cfg.javaPath) return cfg.javaPath;            // user override from Settings
  const have = findJava(); if (have) return have;
  const os = { win32: 'windows', darwin: 'mac', linux: 'linux' }[process.platform];
  const arch = process.arch === 'arm64' ? 'aarch64' : 'x64';
  if (!os) throw new Error('Unsupported OS for automatic Java download.');
  const ext = os === 'windows' ? 'zip' : 'tar.gz';
  const url = `https://api.adoptium.net/v3/binary/latest/21/ga/${os}/${arch}/jre/hotspot/normal/eclipse`;
  const tmp = path.join(DATA, 'runtime', 'java21.' + ext), stage = JAVA_DIR + '.tmp';
  send('progress', { label: 'Downloading Java 21 (one time)', pct: 0 });
  await download(url, tmp, pct => send('progress', { label: 'Downloading Java 21 (one time)', pct }));
  send('progress', { label: 'Installing Java 21', pct: 100 });
  fs.rmSync(stage, { recursive: true, force: true }); fs.mkdirSync(stage, { recursive: true });
  if (ext === 'zip') new AdmZip(tmp).extractAllTo(stage, true);
  else require('child_process').execFileSync('tar', ['-xzf', tmp, '-C', stage]);
  fs.rmSync(JAVA_DIR, { recursive: true, force: true }); fs.renameSync(stage, JAVA_DIR);
  fs.rmSync(tmp, { force: true });
  const exe = findJava(); if (!exe) throw new Error('Java install failed.');
  if (os !== 'windows') fs.chmodSync(exe, 0o755);
  return exe;
}

// ---------- launching ----------
let launching = false;
async function launchGame({ mc, loader, gameRoot, withClient }) {
  if (!session) throw new Error('Sign in with Microsoft first.');
  if (launching) throw new Error('Already launching.');
  launching = true;
  try {
    const javaPath = await ensureJava();
    send('progress', { label: 'Preparing Fabric', pct: 0 });
    const custom = await ensureFabric(mc, loader);
    const warn = (await ensureClientMods(mc, path.join(gameRoot, 'mods'), withClient)).warn;
    if (warn) send('toast', warn);
    const l = new Client();
    l.on('progress', e => send('progress', { label: 'Downloading ' + e.type, pct: Math.round(e.task / e.total * 100) }));
    l.on('debug', e => send('log', e)); l.on('data', e => send('log', e));
    l.on('close', () => { launching = false; send('closed'); win.show(); });
    const proc = await l.launch({
      authorization: session.mclc, root: GAME_DIR, javaPath,
      version: { number: mc, type: 'release', custom },
      memory: { max: cfg.ram + 'G', min: '1G' },
      overrides: { gameDirectory: gameRoot },
      window: { title: 'Party Client' }
    });
    if (!proc) throw new Error('Launch failed. Check your Java path in Settings (leave it blank to use the built-in Java 21).');
    send('launched'); if (cfg.closeOnLaunch) win.minimize();
  } catch (e) { launching = false; throw e; }
}
ipcMain.handle('game:launch', (_, { mc }) => {
  cfg.selected = mc; saveCfg();
  return launchGame({ mc, gameRoot: path.join(INSTANCES, 'vanilla-' + mc), withClient: true });
});

// ---------- modpacks (Modrinth .mrpack, Fabric only) ----------
ipcMain.handle('packs:search', async (_, { q, offset = 0 }) => {
  const facets = encodeURIComponent(JSON.stringify([['project_type:modpack'], ['categories:fabric']]));
  const r = await getJson(`https://api.modrinth.com/v2/search?query=${encodeURIComponent(q || '')}&facets=${facets}&limit=20&offset=${offset}&index=${q ? 'relevance' : 'downloads'}`);
  return r.hits.map(h => ({ id: h.project_id, slug: h.slug, title: h.title, desc: h.description, icon: h.icon_url, downloads: h.downloads, author: h.author }));
});
ipcMain.handle('packs:installed', () => fs.readdirSync(INSTANCES)
  .filter(d => fs.existsSync(path.join(INSTANCES, d, 'party-pack.json')))
  .map(d => ({ dir: d, ...readJson(path.join(INSTANCES, d, 'party-pack.json'), {}) })));
ipcMain.handle('packs:install', async (_, { slug, title }) => {
  const versions = await getJson(`https://api.modrinth.com/v2/project/${slug}/version?loaders=${encodeURIComponent('["fabric"]')}`);
  const v = versions[0]; if (!v) throw new Error('No Fabric version of this pack.');
  const file = v.files.find(f => f.filename.endsWith('.mrpack')) || v.files[0];
  const dir = path.join(INSTANCES, slug); const tmp = path.join(DATA, slug + '.mrpack');
  send('progress', { label: 'Downloading ' + title, pct: 5 }); await download(file.url, tmp);
  const zip = new AdmZip(tmp); const idx = JSON.parse(zip.readAsText('modrinth.index.json'));
  const mc = idx.dependencies.minecraft, loader = idx.dependencies['fabric-loader'];
  const files = idx.files.filter(f => (f.env?.client ?? 'required') !== 'unsupported');
  let n = 0;
  for (const f of files) {
    const dest = path.join(dir, f.path);
    if (!dest.startsWith(dir)) continue; // path traversal guard
    await download(f.downloads[0], dest);
    send('progress', { label: `Installing ${title}`, pct: 5 + Math.round(++n / files.length * 90) });
  }
  for (const pre of ['overrides/', 'client-overrides/']) zip.getEntries().forEach(e => {
    if (!e.isDirectory && e.entryName.startsWith(pre)) {
      const dest = path.join(dir, e.entryName.slice(pre.length));
      if (dest.startsWith(dir)) { fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, e.getData()); }
    }
  });
  fs.rmSync(tmp, { force: true });
  fs.writeFileSync(path.join(dir, 'party-pack.json'), JSON.stringify({ title, slug, mc, loader, version: v.version_number, icon: null }));
  send('progress', { label: 'Done', pct: 100 }); return { mc, loader };
});
ipcMain.handle('packs:play', (_, { dir }) => {
  const meta = readJson(path.join(INSTANCES, dir, 'party-pack.json'), null); if (!meta) throw new Error('Pack missing.');
  return launchGame({ mc: meta.mc, loader: meta.loader, gameRoot: path.join(INSTANCES, dir), withClient: false });
});
ipcMain.handle('packs:remove', (_, { dir }) => { fs.rmSync(path.join(INSTANCES, dir), { recursive: true, force: true }); return true; });

// ---------- settings ----------
ipcMain.handle('cfg:get', () => cfg);
ipcMain.handle('cfg:set', (_, c) => { Object.assign(cfg, c); saveCfg(); return cfg; });
ipcMain.handle('open:folder', () => shell.openPath(DATA));
