Put built Party Client jars here, named partyclient-<ver>+mc<minecraft>.jar
